# Text as Data

if (!require("pacman")) install.packages("pacman")
if (!require("pacman")) install.packages("pacman") # This line is auxilary but tends to provide more robust work with packages
p_load(data.table, dplyr, curl, lubridate, tidyr, haven, stringr, rvest) # two modern packages to modify data objects in R
p_load(ggplot2, ggpubr, ggrepel) # two packages to visualize data
p_load(httr, jsonlite,dplyr)

# You can add your own functions
`%+%` <- function(x,y){paste0(x, y)} # collapse two strings into one
`%gic%` <- function(x,y) {grepl(x, y, ignore.case = TRUE)}
theme_set(theme_pubr(border = TRUE)) # make figures beautiful and ascetic by default

# Assuming the dataset has been loaded into a data.table named 'dt_posts'
dt_posts <- fread("je-suis-maidan-case.csv", fill = T)

# Calculate length of each blog post in characters
dt_posts[, post_length_chars := nchar(BlogPostText)]

# Plotting distribution of post lengths
ggplot(dt_posts, aes(x = PhotoIdentified, y = post_length_chars, fill = PhotoIdentified)) +
  geom_boxplot() +
  labs(title = "Distribution of Post Lengths by Identification Status",
       x = "Photo Identified",
       y = "Post Length (Characters)") +
  theme_minimal()

# Calculate aggregated frequency of syntax characters (e.g., commas, periods, question marks, exclamation points, etc.)
dt_posts[, comma_count := str_count(BlogPostText, fixed(","))]

# Plot distribution of comma usage

# Plot distribution by of syntax characters facet_grid() function

# Plot Post Length by date: individually

# Plot Post Length by date: aggregated 

# Plot Syntax Usage by date: individually

# Plot Syntax Usage by date: aggregated + add the vertical line to denote the date of the protest

# Sentiment Analysis
p_load(syuzhet)

dt_blog_posts <- dt_posts

# Function to get sentiment scores
get_sentiment_score <- function(text) {
  sentiment <- get_sentiment(text, method = "syuzhet")
  return(sentiment)
}

# Calculate sentiment scores for each blog post
dt_blog_posts[, sentiment_score := sapply(BlogPostText, get_sentiment_score)]

# Analyzing the average sentiment score by PhotoIdentified status
avg_sentiment_scores <- dt_blog_posts[, .(avg_sentiment = mean(sentiment_score)), by = PhotoIdentified]

# Plot the average sentiment scores by group

# Plot the average sentiment scores by group and by date + add vertical line 

# Emotional Analysis
# Function to extract dominant emotion from text
get_dominant_emotion <- function(text) {
  emotions <- get_nrc_sentiment(text)
  dominant_emotion <- names(which.max(colSums(emotions)))
  return(dominant_emotion)
}

# Calculate dominant emotions for each blog post

# Plot the average emotional score and by group and before and after the protest event

# Plot the average emotional score by emotion + by date + by group + add vertical line 


# Content Classification with Topic Models
p_load(topicmodels)
p_load(tm)

# Preparing the text data for topic modeling
corpus <- Corpus(VectorSource(dt_blog_posts$BlogPostText))
corpus_clean <- tm_map(corpus, content_transformer(tolower))
corpus_clean <- tm_map(corpus_clean, removePunctuation)
corpus_clean <- tm_map(corpus_clean, removeNumbers)
corpus_clean <- tm_map(corpus_clean, removeWords, stopwords("english"))
corpus_clean <- tm_map(corpus_clean, stripWhitespace)

dtm <- DocumentTermMatrix(corpus_clean)

# Running LDA for topic modeling
lda_result <- LDA(dtm, k = 5, control = list(seed = 1234))

# Examining the top terms in each topic
topics <- terms(lda_result, 6)
print(topics)

# Assigning the dominant topic to each blog post
dominant_topic <- topics(lda_result)

dt_blog_posts[, dominant_topic := dominant_topic]

# Analyzing the distribution of dominant topics by PhotoIdentified status
topic_distribution <- dt_blog_posts[, .N, by = .(PhotoIdentified, dominant_topic)]

# Plotting the distribution of topics
ggplot(topic_distribution, aes(x = factor(dominant_topic), y = N, fill = PhotoIdentified)) +
  geom_bar(stat = "identity", position = "dodge") +
  scale_x_discrete(name = "Dominant Topic", labels = paste("Topic", 1:5)) +
  ylab("Count of Blog Posts") +
  labs(fill = "Photo Identified", title = "Distribution of Dominant Topics by Identification Status") +
  theme_minimal()

# Plot the distribution of topics each topic by date and by topic

# Co-Occurence Network
p_load(igraph)
p_load(ggraph)
# Convert to a matrix and calculate co-occurrence
term_matrix <- as.matrix(dtm)
co_occurrence <- term_matrix %*% t(term_matrix)

# Create a graph object from the co-occurrence matrix
graph <- graph.adjacency(co_occurrence, weighted = TRUE, mode = "undirected")
graph <- simplify(graph)

# Visualize the co-occurrence network
ggraph(graph, layout = "fr") +
  geom_edge_link(aes(width = weight), alpha = 0.5) +
  geom_node_point(color = "blue", size = 5) +
  geom_node_text(aes(label = name), repel = TRUE) +
  theme_graph() +
  labs(title = "Word Co-occurrence Network in Blog Posts")